package pt.ipleiria.estg.dei.ei.dae.academics.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@NamedQueries({
        @NamedQuery(
                name = "getAllStudents",
                query = "SELECT s FROM Student s ORDER BY s.name" // JPQL
        )
})
public class Student extends User {

    @ManyToOne
    @JoinColumn(name = "course_code")
    @NotNull
    private Course course;

    @ManyToMany(fetch = FetchType.LAZY, mappedBy = "teachers")
    private List<Subject> subjects;


    public Student(String username,String password,String name, String email, Course course) {
        super(username, password, name, email);
        this.course = course;
        this.subjects = new ArrayList<>();
    }

    public Student(Course course) {
        this.course = course;
        this.subjects = new ArrayList<>();
    }

    public void addSubject(Subject subject){

        if( !this.subjects.contains(subject)){
            subjects.add(subject);
        }
    }

    public void removeSubject(Subject subject){
        this.subjects.remove(subject);
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<Subject> subjects) {
        this.subjects = subjects;
    }
}
