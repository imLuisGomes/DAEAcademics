package pt.ipleiria.estg.dei.ei.dae.academics.dtos;

import pt.ipleiria.estg.dei.ei.dae.academics.entities.Student;
import pt.ipleiria.estg.dei.ei.dae.academics.entities.Subject;

import java.util.List;
import java.util.stream.Collectors;


public class SubjectDTO{
    private Long code;
    private String name;
    private String courseYear;
    private String schoolarYear;
    private Long courseCode;
    private String courseName;

    public Long getCode() {
        return code;
    }

    public void setCode(Long code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCourseYear() {
        return courseYear;
    }

    public void setCourseYear(String courseYear) {
        this.courseYear = courseYear;
    }

    public String getSchoolarYear() {
        return schoolarYear;
    }

    public void setSchoolarYear(String schoolarYear) {
        this.schoolarYear = schoolarYear;
    }

    public Long getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(Long courseCode) {
        this.courseCode = courseCode;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public SubjectDTO(Long code, String name, String courseYear, String schoolarYear, Long courseCode, String courseName) {
        this.code = code;
        this.name = name;
        this.courseYear = courseYear;
        this.schoolarYear = schoolarYear;
        this.courseCode = courseCode;
        this.courseName = courseName;
    }

    public static SubjectDTO from(Subject subject) {
        return new SubjectDTO(
                subject.getCode(),
                subject.getName(),
                subject.getCourseYear(),
                subject.getScholarYear(),
                subject.getCourse().getCode(),
                subject.getCourse().getName()
                );
    }

    public static List<SubjectDTO> toDTO(List<Subject> subjects) {
        return subjects.stream().map(SubjectDTO::from).collect(Collectors.toList());
    }
}
