package pt.ipleiria.estg.dei.ei.dae.academics.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "subjects",
        uniqueConstraints = @UniqueConstraint(columnNames = {"name", "course_code", "course_year"}) )
@NamedQueries({
        @NamedQuery(
                name = "getAllSubjects",
                query = "SELECT s FROM Subject s ORDER BY s.course, s.scholarYear desc, s.courseYear, s.name" // JPQL
        )
})
public class Subject extends Versionable implements Serializable {

    @Id
    private Long code;

    private String name;

    @ManyToOne
    @JoinColumn(name = "course_code")
    private Course course;

    @Column(name = "course_year")
    private String courseYear;

    @Column(name = "scholar_year")
    private String scholarYear;

    @ManyToMany
    @JoinTable(name = "subjects_students",
            joinColumns = @JoinColumn(name = "subject_code", referencedColumnName = "code"),
            inverseJoinColumns = @JoinColumn(name = "student_username", referencedColumnName =
                    "username"))
    private List<Student> students;

    @ManyToMany
    @JoinTable(name = "subjects_teachers",
            joinColumns = @JoinColumn(name = "subject_code", referencedColumnName = "code"),
            inverseJoinColumns = @JoinColumn(name = "teacher_username", referencedColumnName =
                    "username"))
    private List<Teacher> teachers;
    public Subject(Long code, String name, Course course, String courseYear, String scholarYear) {
        this();
        this.code = code;
        this.name = name;
        this.course = course;
        this.courseYear = courseYear;
        this.scholarYear = scholarYear;
        this.students = new ArrayList<>();
        this.teachers = new ArrayList<>();

    }
    public void addStudent(Student student){

        if( !this.students.contains(student)){
            students.add(student);
        }
    }

    public void removeStudent(Student student){
        this.students.remove(student);
    }

}
