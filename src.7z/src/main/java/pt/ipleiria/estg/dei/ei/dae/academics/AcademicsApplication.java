package pt.ipleiria.estg.dei.ei.dae.academics;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/api")
public class AcademicsApplication extends Application {

}