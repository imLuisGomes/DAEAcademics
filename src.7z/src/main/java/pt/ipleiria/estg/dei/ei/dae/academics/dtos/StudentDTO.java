package pt.ipleiria.estg.dei.ei.dae.academics.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import pt.ipleiria.estg.dei.ei.dae.academics.entities.Student;
import pt.ipleiria.estg.dei.ei.dae.academics.entities.Subject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class StudentDTO implements Serializable {

    private String username;
    private String password;
    private String name;
    private String email;
    private Long courseCode;

    private String courseName;

    private List<SubjectDTO> subjectDTOs;

    public StudentDTO(String username, String password, String name, String email, Long courseCode) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.email = email;
        this.courseCode = courseCode;
        this.subjectDTOs = new ArrayList<>();
    }

    public StudentDTO(String username, String password, String name, String email) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.email = email;
        this.subjectDTOs = new ArrayList<>();
    }

    public static StudentDTO toDTONoSubjects(Student student) {
        return new StudentDTO(
                student.getUsername(),
                student.getPassword(),
                student.getName(),
                student.getEmail(),
                student.getCourse().getCode()
        );
    }

    public static List<StudentDTO> toDTOsNoSubjects(List<Student> students) {
        return students.stream().map(StudentDTO::toDTONoSubjects).collect(Collectors.toList());
    }

    public static StudentDTO toDTO(Student student) {
        return new StudentDTO(
                student.getUsername(),
                student.getPassword(),
                student.getName(),
                student.getEmail(),
                student.getCourse().getCode(),
                student.getCourse().getName(),
                SubjectDTO.toDTO(student.getSubjects())
        );
    }
    public static List<StudentDTO> toDTOs(List<Student> students) {
        return students.stream().map(StudentDTO::toDTO).collect(Collectors.toList());
    }


}
