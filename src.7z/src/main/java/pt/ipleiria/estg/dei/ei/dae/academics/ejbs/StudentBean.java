package pt.ipleiria.estg.dei.ei.dae.academics.ejbs;

import lombok.var;
import org.hibernate.Hibernate;
import pt.ipleiria.estg.dei.ei.dae.academics.entities.Course;
import pt.ipleiria.estg.dei.ei.dae.academics.entities.Student;
import pt.ipleiria.estg.dei.ei.dae.academics.entities.Subject;
import pt.ipleiria.estg.dei.ei.dae.academics.exceptions.MyConstraintViolationException;
import pt.ipleiria.estg.dei.ei.dae.academics.exceptions.MyEntityExistsException;
import pt.ipleiria.estg.dei.ei.dae.academics.exceptions.MyEntityNotFoundException;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.*;
import javax.validation.ConstraintViolationException;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

@Stateless
public class StudentBean {

    @PersistenceContext
    private EntityManager entityManager;

    @EJB
    private CourseBean courseBean;

    @EJB
    private SubjectBean subjectBean;


    public boolean exists(String username) {
        var query = entityManager.createQuery(
                "SELECT COUNT(s.username) FROM " + Student.class.getSimpleName() +" s WHERE s.username = :username",
                Long.class
        );
        query.setParameter("username", username);
        return query.getSingleResult() > 0;
    }

    public void create(
            String username,
            String password,
            String name,
            String email,
            long courseCode
    ) throws MyEntityExistsException, MyEntityNotFoundException, MyConstraintViolationException {
        if (exists(username)) {
            throw new MyEntityExistsException(
                    "Student with username '" + username + "' already exists"
            );
        }
        Course course = courseBean.findCourse(courseCode);
        if (course == null) {
            throw new MyEntityNotFoundException(
                    "Course with code '" + courseCode + "' not found"
            );
        }
        try {
           Student s = new Student(username, password, name, email, course);
            course.addStudent(s);
            entityManager.persist(s);
        } catch (ConstraintViolationException e) {
            throw new MyConstraintViolationException(e);
        }
    }



    public List<Student> getAllStudents() {
        // remember, maps to: “SELECT s FROM Student s ORDER BY s.name”
        return (List<Student>) entityManager.createNamedQuery("getAllStudents", Student.class).getResultList();
    }

    public Student findStudent(String username) {
        Student student = entityManager.find(Student.class, username);

        Hibernate.initialize(student.getSubjects());

        return student;
    }

    public Student findOrFail(String username){
        Student student =  findStudent(username);

        if( student == null ){
            throw new MyEntityNotFoundException("Student not found: " + username);
        }

        Hibernate.initialize(student.getSubjects());
        return student;
    }

    public void update(String username, String password, String name, String email, Long courseCode) {
        Student student = entityManager.find(Student.class, username);
        if (student == null) {
            System.err.println("ERROR_STUDENT_NOT_FOUND: " + username);
            return;
        }
        entityManager.lock(student, LockModeType.OPTIMISTIC);
        student.setPassword(password);
        student.setName(name);
        student.setEmail(email);
        // a "lazy way" that avoids querying the course every time we do an update to the student
        // plus: why we don't check if the other attributes changed too?
        if (!Objects.equals(student.getCourse().getCode(), courseCode)) {
            Course course = entityManager.find(Course.class, courseCode);
            if (course == null) {
                System.err.println("ERROR_COURSE_NOT_FOUND: " + courseCode);
                return;
            }
            student.setCourse(course);
        }
    }

    public void enrollStudentInSubject(String username, Long subjectCode){

        Student student = findStudent(username);
        Subject subject = subjectBean.findSubject(subjectCode);

        if(!student.getCourse().equals(subject.getCourse())) return;

        student.addSubject(subject);
        subject.addStudent(student);
    }

}
