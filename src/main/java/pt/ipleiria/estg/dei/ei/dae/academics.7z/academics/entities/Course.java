package pt.ipleiria.estg.dei.ei.dae.academics.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Data
@AllArgsConstructor
@Table(
        name = "courses",
        uniqueConstraints = @UniqueConstraint(columnNames = {"name"})
)
@NamedQueries({
        @NamedQuery(
                name = "getAllCourses",
                query = "SELECT c FROM Course c ORDER BY c.name" // JPQL
        )
})
public class Course implements Serializable {

    @Id
    private Long code;

    @NotNull
    @Column(nullable = false)
    private String name;

    @OneToMany(mappedBy = "course", cascade = CascadeType.REMOVE)
    private List<Student> students;

    @OneToMany(mappedBy = "course", cascade = CascadeType.REMOVE)
    private List<Subject> subjects;

    public Course(Long code, String name) {
        this();
        this.code = code;
        this.name = name;
        this.subjects = new ArrayList<>();
        this.students = new ArrayList<>();
    }


    public Course() {
    }

    public void addStudent(Student student){

        if( !this.students.contains(student)){
            students.add(student);
        }
    }

    public void removeStudent(Student student){
        this.students.remove(student);
    }

    public void addSubject(Subject subject){

        if( !this.subjects.contains(subject)){
            subjects.add(subject);
        }
    }

    public void removeSubject(Subject subject){
        this.subjects.remove(subject);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Course course = (Course) o;
        return code.equals(course.code);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, name);
    }
}
