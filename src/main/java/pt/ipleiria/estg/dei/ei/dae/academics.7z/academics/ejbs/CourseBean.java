package pt.ipleiria.estg.dei.ei.dae.academics.ejbs;

import pt.ipleiria.estg.dei.ei.dae.academics.entities.Course;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class CourseBean {

    @PersistenceContext
    private EntityManager entityManager;

    public void create(Long code, String name ){

        entityManager.persist(new Course( code, name));
    }

    public List<Course> getAllCourses() {
        // remember, maps to: “SELECT c FROM Course s ORDER BY c.name”
        return (List<Course>) entityManager.createNamedQuery("getAllCourses", Course.class).getResultList();
    }

    public Course findCourse(Long courseCod) {
        return entityManager.find(Course.class, courseCod);
    }

}
