package pt.ipleiria.estg.dei.ei.dae.academics.ejbs;


import pt.ipleiria.estg.dei.ei.dae.academics.entities.Teacher;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;

@Startup
@Singleton
public class ConfigBean {

    @EJB
    private StudentBean studentBean;

    @EJB
    private CourseBean courseBean ;

    @EJB
    private SubjectBean subjectBean ;

    @EJB
    private AdministratorBean administratorBean ;

    @EJB
    private TeacherBean teacherBean ;

    @PostConstruct
    public void populateDB() {
        courseBean.create(1000L, "EI");
        courseBean.create(1001L, "JDM");
        courseBean.create(1002L, "GES");

        subjectBean.create(2000L, "DAE", 1000L, "22/23", "EI22/23");


        studentBean.create("Luis", "1234567", "Student 1","Student@mail.pt", 1000L);
        studentBean.create("Joao", "1234567", "Student 2","Student2@mail.pt", 1001L);

        studentBean.enrollStudentInSubject("Luis", 2000L);

        //administratorBean.create("Admin", "123456", "Admin1", "Admin@mail.pt");

        teacherBean.create("Ricardo", "Riczao", "Ricardo", "ricardo@mail.pt", "13");

    }
}
