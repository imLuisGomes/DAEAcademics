package pt.ipleiria.estg.dei.ei.dae.academics.ejbs;

import pt.ipleiria.estg.dei.ei.dae.academics.entities.Course;
import pt.ipleiria.estg.dei.ei.dae.academics.entities.Student;
import pt.ipleiria.estg.dei.ei.dae.academics.entities.Subject;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;
import javax.persistence.PersistenceContext;
import java.util.LinkedList;
import java.util.List;

@Stateless
public class StudentBean {

    @PersistenceContext
    private EntityManager entityManager;

    @EJB
    private CourseBean courseBean;

    @EJB
    private SubjectBean subjectBean;


    public void create(String username, String password, String name, String email, Long courseCode){
       Course course = entityManager.find(Course.class, courseCode);
       if(course == null){
           throw  new EntityNotFoundException("Course does not exist");
       }

       Student student = new Student(username, password, name, email, course);

        entityManager.persist(student);
        course.addStudent(student);
    }

    public List<Student> getAllStudents() {
        // remember, maps to: “SELECT s FROM Student s ORDER BY s.name”
        return (List<Student>) entityManager.createNamedQuery("getAllStudents", Student.class).getResultList();
    }

    public Student findStudent(String username) {
        return entityManager.find(Student.class, username);
    }

    public void enrollStudentInSubject(String username, Long subjectCode){

        Student student = findStudent(username);
        Subject subject = subjectBean.findSubject(subjectCode);

        if(!student.getCourse().equals(subject.getCourse())) return;

        student.addSubject(subject);
        subject.addStudent(student);

    }

}
