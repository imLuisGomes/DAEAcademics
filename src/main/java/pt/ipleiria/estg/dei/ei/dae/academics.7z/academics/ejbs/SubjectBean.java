package pt.ipleiria.estg.dei.ei.dae.academics.ejbs;

import pt.ipleiria.estg.dei.ei.dae.academics.entities.Course;
import pt.ipleiria.estg.dei.ei.dae.academics.entities.Subject;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class SubjectBean {

    @PersistenceContext
    private EntityManager entityManager;

    @EJB
    private CourseBean courseBean;

    public void create(Long code, String name, Long courseCod, String courseYear, String scholarYear){
        Course course = courseBean.findCourse(courseCod);
        if (course == null) return;

        Subject subject = new Subject(code, name, course, courseYear, scholarYear);

        entityManager.persist(subject);
        course.addSubject(subject);
    }

    public List<Subject> getAllSubjects() {
        // remember, maps to: “SELECT s FROM Student s ORDER BY s.name”
        return (List<Subject>) entityManager.createNamedQuery("getAllSubjects", Subject.class).getResultList();
    }

    public Subject findSubject(Long subjectCode) {
        return entityManager.find(Subject.class, subjectCode);
    }

}
